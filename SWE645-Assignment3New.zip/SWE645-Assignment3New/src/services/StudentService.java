package services;

import bean.Student;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 * This is the service class to save the student survey details into a file
 * and retrieve the details from the file
 * 
 * @author Bhavana Ramasayam
 */

@ManagedBean
@RequestScoped
public class StudentService {

    private ArrayList<Student> studentsSurvey;

    public ArrayList<Student> getStudentsSurvey() {
        return studentsSurvey;
    }

    public void setStudentsSurvey(ArrayList<Student> studentsSurvey) {
        this.studentsSurvey = studentsSurvey;
    }

    public void saveData(Student student) {
        String appendedLikeCamp = "";
        for (String likeCamp : student.getCampusLike()) {
            appendedLikeCamp += likeCamp;
        }

        String data = student.getFirstName() + ","
                + student.getLastName() + ","
                + student.getStreetAddress() + ","
                + student.getCity() + ","
                + student.getState() + ","
                + student.getZip() + ","
                + student.getTelNumber() + ","
                + student.getEmail() + ","
                + new SimpleDateFormat("MMM dd yyyy").format(student.getDateOfSurvey())+ ","
               //+ student.getDateOfSurvey()+ ","
                + appendedLikeCamp + ","
                + student.getUniversityInterest() + ","
                + student.getSchoolRecommend() + ","
                + student.getAddComm();

        try {
            File studentSurveyFile = new File("studentSurveyFileNew2.txt");
            if (!studentSurveyFile.exists()) {
                studentSurveyFile.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(studentSurveyFile.getAbsoluteFile(), true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            bufferedWriter.write(data);
            bufferedWriter.newLine();

            bufferedWriter.close();
        } catch (IOException ex) {
            System.out.println("Error writing to file " + ex.getMessage());
        }
    }

    public String retrieveStudentsSurvey() throws ParseException {
        String fileName = "studentSurveyFileNew2.txt";
        String oneStudentsSurvey;

        try {
            FileReader fileReader = new FileReader(fileName);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            ArrayList<Student> studentsSurvey1 = new ArrayList<Student>();
            while ((oneStudentsSurvey = bufferedReader.readLine()) != null) {
                String[] oneStudentsSurveyData = oneStudentsSurvey.split(",");
                if (oneStudentsSurveyData.length > 1) {
                    Student student = new Student();
                    student.setFirstName(oneStudentsSurveyData[0]);
                    student.setLastName(oneStudentsSurveyData[1]);
                    student.setStreetAddress(oneStudentsSurveyData[2]);
                    student.setCity(oneStudentsSurveyData[3]);
                    student.setState(oneStudentsSurveyData[4]);
                    student.setZip(oneStudentsSurveyData[5]);
                    student.setTelNumber(oneStudentsSurveyData[6]);
                    student.setEmail(oneStudentsSurveyData[7]);
                    
                    DateFormat format = new SimpleDateFormat("MMM dd yyyy");
                    Date surveyDate = format.parse(oneStudentsSurveyData[8]);
                    student.setDateOfSurvey(surveyDate);

                    student.setStringAppendedCampusLike(oneStudentsSurveyData[9]);
                    student.setUniversityInterest(oneStudentsSurveyData[10]);
                    student.setSchoolRecommend(oneStudentsSurveyData[11]);
                    student.setAddComm(oneStudentsSurveyData[12]);

                    studentsSurvey1.add(student);
                }
            }

            setStudentsSurvey(studentsSurvey1);

            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Unable to open file '" + fileName + "'");
        } catch (IOException ex) {
            System.out.println("Error reading file '" + fileName + "'");
        }

        return "listSurvey";
    }
}